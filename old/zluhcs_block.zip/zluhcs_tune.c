#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>
#include <ctype.h>

#ifdef _DEBUG
int play(int by_turn, int games, int display);
void set_eval_values(double heigh, double lines, double holes, double bumps, double multi);
void optimize(double initial_guess[5]);

//double	EV_HEIGHTS = -0.510066;
//double	EV_LINES   =  0.760666;
//double	EV_HOLES   = -0.956630;
//double	EV_BUMPS   = -0.284483;
//double	EV_MULTI   =  0.125000;
void tune(void) {
	double	params[5] = {-0.510066, 0.760666, -0.956630, -0.284483, 0.125000};

	optimize(params);

	//printf("tune points: %d\n", play(0, 100, 0));

}

int get_points(double params[5]) {
	set_eval_values(params[0], params[1], params[2], params[3], params[4]);
	return play(0, 100, 0);
}

void optimize(double initial_guess[5]) {
	int		param_count = 5;
	int		best_points = get_points(initial_guess);
	int		new_points;
	double	best_values[5];
	double	new_values[5];
	int		improved = 1;
	int		pi;
	int		x;

	for (x = 0; x < 5; x++) best_values[x] = initial_guess[x];

	printf("initial_values: ");
	for (x = 0; x < 5; x++) {
		printf("%2.4f ", best_values[x]);
	}
	printf("points: %d\n", best_points);

	while(improved) {
		improved = 0;

		for (pi = 0; pi < param_count; pi++) {
			for (x = 0; x < 5; x++) new_values[x] = best_values[x];
			new_values[pi] += 0.25;
			new_points = get_points(new_values);
			if (new_points > best_points) {
				best_points = new_points;
				for (x = 0; x < 5; x++) best_values[x] = new_values[x];
				improved = 1;
			}
			else {
				new_values[pi] -= 0.50;
				new_points = get_points(new_values);
				if (new_points > best_points) {
					best_points = new_points;
					for (x = 0; x < 5; x++) best_values[x] = new_values[x];
					improved = 1;
				}
			}
			printf("values: ");
			for (x = 0; x < 5; x++) {
				printf("%2.4f ", best_values[x]);
			}
			printf("points: %d\n", best_points);
		}

	}

	printf("done.\n");
}

#endif

//vector<int> localOptimize(const vector<int>& initialGuess) {
//   const int nParams = initialGuess.size();
//   double bestE = E(initialGuess);
//   vector<int> bestParValues = initialGuess;
//   bool improved = true;
//   while ( improved ) {
//      improved = false;
//      for (int pi = 0; pi < nParams; pi++) {
//         vector<int> newParValues = bestParValues;
//         newParValues[pi] += 1;
//         double newE = E(newParValues);
//         if (newE < bestE) {
//            bestE = newE;
//            bestParValues = newParValues;
//            improved = true;
//         } else {
//            newParValues[pi] -= 2;
//            newE = E(newParValues);
//            if (newE < bestE) {
//               bestE = newE;
//               bestParValues = newParValues;
//               improved = true;
//            }
//         }
//      }
//   }
//   return bestParValues;
//}
