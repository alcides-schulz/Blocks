//-------------------------------------------------------------------------
// TheAiGames's block bot by Alcides Schulz (zluchs)
//-------------------------------------------------------------------------
#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>
#include <ctype.h>

#define CELL_EMPTY  '0'
#define CELL_SHAPE  '1'
#define CELL_BLOCK  '2'
#define CELL_SOLID  '3'

typedef struct s_game_settings {
    int     timebank;
    int     time_per_move;
    char    player_names[512];
    char    my_bot_name[512];
    int     field_height;
    int     field_width;
}   GAME_SETTINGS;

typedef struct s_game_state {
    int     round;
    char    this_piece_type;
    char    next_piece_type;
    int     this_piece_position_row;
    int     this_piece_position_col;
}   GAME_STATE;

typedef struct s_player {
    int     row_points;
    int     combo;
    int     skips;
    char    *field;
}   PLAYER;

typedef struct s_piece {
    char    type;
    char    **shapes;
    int     max_shapes;
    int     current_shape;
    int     size;
    int     row;
    int     col;
}   PIECE;

typedef struct s_move {
	int		score;
	int		shape;
	int		row;
	int		col;
}	MOVE;

typedef struct s_move_list {
	int		count;
	MOVE	moves[100];
}	MOVE_LIST;

GAME_SETTINGS   game_settings;
GAME_STATE      game_state;
PLAYER          my_player;
PLAYER          opp_player;

char *SHAPE_TYPES = "IZLJOTS";

char *I_SHAPE[4] = {"0000111100000000", "0010001000100010", "0000000011110000", "0100010001000100"};
char *Z_SHAPE[4] = {"110011000", "001011010", "000110011", "010110100"};
char *L_SHAPE[4] = {"001111000", "010010011", "000111100", "110010010"};
char *J_SHAPE[4] = {"100111000", "011010010", "000111001", "010010110"};
char *O_SHAPE[1] = {"1111"};
char *T_SHAPE[4] = {"010111000", "010011010", "000111010", "010110010"};
char *S_SHAPE[4] = {"011110000", "010011001", "000011110", "100110010"};
 
void settings(char *type, char *value);
void update(char *player, char *type, char *value);
void update_player(PLAYER *player, char *type, char *value);
void action(char *action, char *time);
void do_moves(int time);
void find_lowest_row(char *field, PIECE *piece, int *lowest_row, int *lowest_col);
void place_piece(char *field, PIECE *piece, int row, int col);
void remove_piece(char *field, PIECE *piece, int row, int col);
void find_best_drop(char *field, PIECE *piece, int *best_row, int *best_col, int *best_shape);

void init_piece(PIECE *piece, char type);
void rotate_right(PIECE *piece);
void rotate_left(PIECE *piece);
void print_piece(PIECE *piece);

void test(void);
void print_player(struct s_player *player);

int main(void) {
    char    line[16384];
    char    part[3][1024];

    memset(&game_settings, 0, sizeof(GAME_SETTINGS));
    memset(&game_state, 0, sizeof(GAME_STATE));
    memset(&my_player, 0, sizeof(PLAYER));
    memset(&opp_player, 0, sizeof(PLAYER));

    while(fgets(line, 16384, stdin) != NULL) {
        if (!strncmp(line, "settings ", 9)) {
            sscanf(&line[9], "%s %s", part[0], part[1]);
            settings(part[0], part[1]);
            continue;
        }
        if (!strncmp(line, "update ", 7)) {
            sscanf(&line[7], "%s %s %s", part[0], part[1], part[2]);
            update(part[0], part[1], part[2]);
            continue;
        }
        if (!strncmp(line, "action ", 7)) {
            sscanf(&line[7], "%s %s", part[0], part[1]);
            action(part[0], part[1]);
			fflush(stdout);
            continue;
        }
        //if (!strncmp(line, "test", 4))
        //    test();
    }

    return 0;
}

void test(void) {
    char	p[100];
	int		i;

	settings("timebank", "10000");
	settings("time_per_move", "500");
	settings("player_names", "player1,player2");
	settings("your_bot", "player2");
	settings("field_width", "10");
	settings("field_height", "20");

	update("game", "round", "1");
	update("game", "this_piece_type", "I");
	update("game", "next_piece_type", "J");
	update("game", "this_piece_position", "3,-1");

	update("player2", "row_points", "0");
	update("player2", "combo", "0");
	update("player2", "skips", "0");
	update("player2", "field", "0,0,0,1,1,1,1,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0");

	update("player1", "row_points", "0");
	update("player1", "combo", "0");
	update("player1", "skips", "0");
	update("player1", "field", "0,0,0,1,1,1,1,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0");

	while(1) {
		printf("\npiece: ");
		fflush(stdout);
		gets(p);
		if (p == NULL)
			break;
		game_state.this_piece_type = toupper(p[0]);
		do_moves(0);
		for (i = 0; i < game_settings.field_height * game_settings.field_width; i++)
			if (my_player.field[i] != CELL_EMPTY)
				my_player.field[i] = CELL_BLOCK;
	}
}

void action(char *type, char *time) {
    assert(type != NULL);
    assert(time != NULL);
    
    if (!strcmp(type, "moves"))
        do_moves(atoi(time));
    else
        fprintf(stderr, "action: unknown type: [%s]\n", type);
}

void do_moves(int time) {
    PIECE   this_piece;
    PIECE   next_piece;
    int     best_row;
    int     best_col;
    int     best_shape;
    int     i;
    
    init_piece(&this_piece, game_state.this_piece_type);
    init_piece(&next_piece, game_state.next_piece_type);

    //find_lowest_row(my_player.field, &this_piece, &lowest_row, &lowest_col);
    find_best_drop(my_player.field, &this_piece, &best_row, &best_col, &best_shape);
	
	for (i = 0; i < best_shape; i++)
		fprintf(stdout, "TURNRIGHT,");

    if (best_col < game_state.this_piece_position_col) {
		for (i = best_col; i < game_state.this_piece_position_col; i++) {
            fprintf(stdout, "LEFT,");
		}
    }
    else {
		for (i = game_state.this_piece_position_col; i < best_col; i++) {
            fprintf(stdout, "RIGHT,");
		}
    }
    
    fprintf(stdout, "DROP\n");

	//this_piece.current_shape = best_shape;
	//place_piece(my_player.field, &this_piece, best_row, best_col);
	//print_player(&my_player);
}

void place_piece(char *field, PIECE *piece, int row, int col) {
    int     prow;
    int     pcol;
    
    for (prow = 0; prow < piece->size; prow++) {
        for (pcol = 0; pcol < piece->size; pcol++) {
            if (piece->shapes[piece->current_shape][prow * piece->size + pcol] == CELL_EMPTY)
                continue;
            field[(row + prow) * game_settings.field_width + (col + pcol)] = CELL_SHAPE;
        }
    }
}

void remove_piece(char *field, PIECE *piece, int row, int col) {
    int     prow;
    int     pcol;
    
    for (prow = 0; prow < piece->size; prow++) {
        for (pcol = 0; pcol < piece->size; pcol++) {
            if (piece->shapes[piece->current_shape][prow * piece->size + pcol] == CELL_EMPTY)
                continue;
            field[(row + prow) * game_settings.field_width + (col + pcol)] = CELL_EMPTY;
        }
    }
}

int can_drop(char *field, int row, int col, PIECE *piece) {
    int     prow;
    int     pcol;

	int		i;

	for (prow = 0; prow < piece->size; prow++) {
		for (pcol = 0; pcol < piece->size; pcol++) {
            if (piece->shapes[piece->current_shape][prow * piece->size + pcol] == CELL_EMPTY)
                continue;
			for (i = row + prow - 1; i > 0; i--) {
				if (field[i * game_settings.field_width + (col + pcol)] != CELL_EMPTY)
					return 0;
			}
		}
	}
	return 1;
}

int piece_fits_at(char *field, int row, int col, PIECE *piece) {
    int     pc_row;
    int     pc_col;
	int		bk_row;
	int		bk_col;
    
    for (pc_row = 0; pc_row < piece->size; pc_row++) {
        for (pc_col = 0; pc_col < piece->size; pc_col++) {

            if (piece->shapes[piece->current_shape][pc_row * piece->size + pc_col] == CELL_EMPTY)
                continue;

			bk_row = row + pc_row;
			bk_col = col + pc_col;

            if (bk_row < 0 || bk_row >= game_settings.field_height)
                return 0;
            if (bk_col < 0 || bk_col >= game_settings.field_width)
                return 0;

            if (field[bk_row * game_settings.field_width + bk_col] != CELL_EMPTY)
                return 0;
        }
    }

    return 1;
}

void find_lowest_row(char *field, PIECE *piece, int *lowest_row, int *lowest_col) {
    int     row;
    int     col;
	int		best_row = -1;
    
    assert(lowest_row != NULL);
    assert(lowest_col != NULL);
    
    *lowest_row = *lowest_col = 0;
    
    for (row = 0; row < game_settings.field_height; row++) {
        for (col = 0; col < game_settings.field_width; col++) {
			if (piece_fits_at(field, row, col, piece)) {
				if (can_drop(field, row, col, piece)) {
					if (row > best_row) {
						*lowest_row = row;
						*lowest_col = col;
						best_row = row;
					}
				}
            }
        }
    }
}

void gen_moves(PIECE *piece, MOVE_LIST *move_list) {
	int		i;

	move_list->count = 0;
	
	for (i = 0; i < piece->max_shapes; i++) {
		memset(&move_list->moves[move_list->count], 0, sizeof(MOVE));
		move_list->moves[move_list->count].shape = i;
		move_list->count++;
	}
}

int evaluate(char *field, int from_row) {
	int		row;
	int		col;
	int		score = 0;
	int		fill;

	for (row = from_row; row < game_settings.field_height; row++) {
		if (field[row * game_settings.field_width] == CELL_SOLID)
			continue;
		fill = 0;
		for (col = 0; col < game_settings.field_width; col++) {
			if (field[row * game_settings.field_width + col] == CELL_EMPTY)
				continue;
			fill++;
		}
		score += row * fill;
		if (fill == game_settings.field_width)
			score += 100;
	}
	return score;
}

void find_best_drop(char *field, PIECE *piece, int *best_row, int *best_col, int *best_shape) {
    int     row;
    int     col;
	int		score;
	int		i;
	MOVE_LIST	move_list;
	int		best_score;
	int		best_move;
    
    assert(best_row != NULL);
    assert(best_col != NULL);
    
    gen_moves(piece, &move_list);

	for (i = 0; i < move_list.count; i++) {
		piece->current_shape = move_list.moves[i].shape;
		for (row = 0; row < game_settings.field_height; row++) {
			for (col = -1; col < game_settings.field_width; col++) {
				if (piece_fits_at(field, row, col, piece)) {
					if (can_drop(field, row, col, piece)) {
						place_piece(field, piece, row, col);
						score = evaluate(field, row);
						if (score >= move_list.moves[i].score) { 
							move_list.moves[i].score = score;
							move_list.moves[i].row = row;
							move_list.moves[i].col = col;
						}
						remove_piece(field, piece, row, col);
					}
				}
			}
		}
	}
	piece->current_shape = 0;
	best_score = -1;
	best_move = 0;
	for (i = 0; i < move_list.count; i++) {
		if (move_list.moves[i].score > best_score) {
			best_move = i;
			best_score = move_list.moves[i].score;
		}
	}

    *best_row = move_list.moves[best_move].row;
	*best_col = move_list.moves[best_move].col;
	*best_shape = move_list.moves[best_move].shape;
}

void settings(char *type, char *value) {

    assert(type != NULL);
    assert(value != NULL);
    
    if (!strcmp(type, "timebank"))
        game_settings.timebank = atoi(value);
    else
    if (!strcmp(type, "time_per_move"))
        game_settings.time_per_move = atoi(value);
    else
    if (!strcmp(type, "player_names"))
        strcpy(game_settings.player_names, value);
    else
    if (!strcmp(type, "your_bot"))
        strcpy(game_settings.my_bot_name, value);
    else
    if (!strcmp(type, "field_height"))
        game_settings.field_height = atoi(value);
    else
    if (!strcmp(type, "field_width"))
        game_settings.field_width = atoi(value);
    else
        fprintf(stderr, "settings: unknown type: [%s]\n", type);
}

void update(char *player, char *type, char *value) {

    assert(player != NULL);
    assert(type != NULL);
    assert(value != NULL);

    if (!strcmp(player, "game")) {
        if (!strcmp(type, "round"))
            game_state.round = atoi(value);
        else
        if (!strcmp(type, "this_piece_type"))
            game_state.this_piece_type = value[0];
        else
        if (!strcmp(type, "next_piece_type"))
            game_state.next_piece_type = value[0];
        else
        if (!strcmp(type, "this_piece_position"))
            sscanf(value, "%d,%d", &game_state.this_piece_position_col, &game_state.this_piece_position_row);
        else
            fprintf(stderr, "update: unknown game type: [%s]\n", type);
        return;
    }

    if (!strcmp(player, game_settings.my_bot_name))
        update_player(&my_player, type, value);
    else
        update_player(&opp_player, type, value);
}

void update_player(PLAYER *player, char *type, char *value) {
    int     row;
    int     col;
    int     i;

    assert(player != NULL);
    assert(type != NULL);
    assert(value != NULL);
    
    if (!strcmp(type, "row_points"))
        player->row_points = atoi(value);
    else
    if (!strcmp(type, "combo"))
        player->combo = atoi(value);
    else
    if (!strcmp(type, "skips"))
        player->skips = atoi(value);
    else
    if (!strcmp(type, "field")) {
        if (player->field == NULL) {
            player->field = (char *)malloc(game_settings.field_height * game_settings.field_width);
            if (player->field == NULL) {
                fprintf(stderr, "update_player: malloc failed for player->field.\n");
                return;
            }
        }
        for (row = col = i = 0; value[i]; i++) {
            switch(value[i]) {
            case ',': col++; break;
            case ';': row++; col = 0; break;
            default: player->field[row * game_settings.field_width + col] = value[i]; break;
            }
       }
    }
    else
        fprintf(stderr, "update_player: unknown type: [%s]\n", type);
}

char field_cell_string(char cell) {
    switch(cell) {
    case CELL_EMPTY: return ' ';
    case CELL_SHAPE: return '*';
    case CELL_BLOCK: return '+';
    case CELL_SOLID: return 'X';
    default: return '?';
    }
}

void print_player(PLAYER *player) {
    int     row;
    int     col;

    assert(player != NULL);

    fprintf(stderr, "row_points: %d combo: %d skips: %d\n", player->row_points, player->combo, player->skips);

    for (row = 0; row < game_settings.field_height; row++) {
        fprintf(stderr, "   ");
        for (col = 0; col < game_settings.field_width; col++)
            fprintf(stderr, "+---");
        fprintf(stderr, "+\n");

        for (col = 0; col < game_settings.field_width; col++) {
            if (col == 0)
                fprintf(stderr, "%2d |", row);
            fprintf(stderr, " %c |", field_cell_string(player->field[row * game_settings.field_width + col]));
        }

        fprintf(stderr, " %2d\n", row);
    }

    fprintf(stderr, "   ");
    for (col = 0; col < game_settings.field_width; col++)
        fprintf(stderr, "+---");
    fprintf(stderr, "+\n");
}

void init_piece(PIECE *piece, char type)
{
    assert(piece != NULL);

    memset(piece, 0, sizeof(PIECE));

    switch(type) {
    case 'I':
        piece->type = 'I';
        piece->size = 4;
        piece->current_shape = 0;
        piece->shapes = I_SHAPE;
        piece->max_shapes = 4;
        break;
    case 'Z':
        piece->type = 'Z';
        piece->size = 3;
        piece->current_shape = 0;
        piece->shapes = Z_SHAPE;
        piece->max_shapes = 4;
        break;
    case 'L':
        piece->type = 'L';
        piece->size = 3;
        piece->current_shape = 0;
        piece->shapes = L_SHAPE;
        piece->max_shapes = 4;
        break;
    case 'J':
        piece->type = 'J';
        piece->size = 3;
        piece->current_shape = 0;
        piece->shapes = J_SHAPE;
        piece->max_shapes = 4;
        break;
    case 'O':
        piece->type = 'O';
        piece->size = 2;
        piece->current_shape = 0;
        piece->shapes = O_SHAPE;
        piece->max_shapes = 1;
        break;
    case 'T':
        piece->type = 'T';
        piece->size = 3;
        piece->current_shape = 0;
        piece->shapes = T_SHAPE;
        piece->max_shapes = 4;
        break;        
    case 'S':
        piece->type = 'S';
        piece->size = 3;
        piece->current_shape = 0;
        piece->shapes = S_SHAPE;
        piece->max_shapes = 4;
        break; 
    default:
        fprintf(stderr, "init_piece: unknown type: [%c]\n", type);
    }
}

void rotate_right(PIECE *piece) {
    assert(piece != NULL);
	if (piece->current_shape == piece->max_shapes - 1)
		piece->current_shape = 0;
	else
		piece->current_shape++;
}

void rotate_left(PIECE *piece) {
    assert(piece != NULL);
	if (piece->current_shape == 0)
		piece->current_shape = piece->max_shapes - 1;
	else
		piece->current_shape--;
}

void print_piece(PIECE *piece) {
    int     row;
    int     col;

    assert(piece != NULL);

    for (row = 0; row < piece->size; row++) {
        for (col = 0; col < piece->size; col++)
            fprintf(stderr, "+-");
        fprintf(stderr, "+\n");
        fprintf(stderr, "|");

        for (col = 0; col < piece->size; col++)
            fprintf(stderr, "%c|", (piece->shapes[piece->current_shape][row * piece->size + col] == '1' ? CELL_BLOCK : CELL_EMPTY));
        fprintf(stderr, "\n");
    }

    for (col = 0; col < piece->size; col++)
        fprintf(stderr, "+-");
    fprintf(stderr, "+\n\n");
}

// END
