#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>

#define CELL_EMPTY  ' '
#define CELL_SHAPE  '+'
#define CELL_BLOCK  '*'
#define CELL_SOLID  'X'
#define CELL_UNKNOWN '?'

typedef struct s_game_settings {
    int     timebank;
    int     time_per_move;
    char    player_names[512];
    char    my_bot_name[512];
    int     field_height;
    int     field_width;
}   GAME_SETTINGS;

typedef struct s_game_state {
    int     round;
    char    this_piece_type;
    char    next_piece_type;
    int     this_piece_position_row;
    int     this_piece_position_col;
}   GAME_STATE;

typedef struct s_player {
    int     row_points;
    int     combo;
    int     skips;
    char    *field;
}   PLAYER;

typedef struct s_piece {
    char    type;
    char    **shapes;
    int     max_shapes;
    int     current_shape;
    int     size;
    int     row;
    int     col;
}   PIECE;

GAME_SETTINGS   game_settings;
GAME_STATE      game_state;
PLAYER          my_player;
PLAYER          opp_player;

char *SHAPE_TYPES = "IZLJOTS";

char *I_SHAPE[4] = {"0000111100000000", "0010001000100010", "0000000011110000", "0100010001000100"};
char *Z_SHAPE[4] = {"110011000", "001011010", "000110011", "010110100"};
char *L_SHAPE[4] = {"001111000", "010010011", "000111100", "110010010"};
char *J_SHAPE[4] = {"100111000", "011010010", "000111001", "010010110"};
char *O_SHAPE[1] = {"1111"};
char *T_SHAPE[4] = {"010111000", "010011010", "000111010", "010110010"};
char *S_SHAPE[4] = {"011110000", "010011001", "000011110", "100110010"};
 
void settings(char *type, char *value);
void update(char *player, char *type, char *value);
void update_player(PLAYER *player, char *type, char *value);
void action(char *action, char *time);
void do_moves(int time);
void find_lowest_row(char *field, PIECE *piece, int *lowest_row, int *lowest_col);
void set_piece(char *field, PIECE *piece, int row, int col);

void init_piece(PIECE *piece, char type);
void rotate_right(PIECE *piece);
void rotate_left(PIECE *piece);
void print_piece(PIECE *piece);

void test(void);
void print_player(struct s_player *player);

int main(void) {
    char    line[16384];
    char    part[3][1024];

    memset(&game_settings, 0, sizeof(GAME_SETTINGS));
    memset(&game_state, 0, sizeof(GAME_STATE));
    memset(&my_player, 0, sizeof(PLAYER));
    memset(&opp_player, 0, sizeof(PLAYER));

    while(fgets(line, 16384, stdin) != NULL) {

        assert(strlen(line) < 1024);

		//fprintf(stderr, "line: [%s]\n", line);

        if (!strncmp(line, "settings ", 9)) {
            sscanf(&line[9], "%s %s", part[0], part[1]);
            settings(part[0], part[1]);
            continue;
        }

        if (!strncmp(line, "update ", 7)) {
            sscanf(&line[7], "%s %s %s", part[0], part[1], part[2]);
            update(part[0], part[1], part[2]);
            continue;
        }

        if (!strncmp(line, "action ", 7)) {
            sscanf(&line[7], "%s %s", part[0], part[1]);
            action(part[0], part[1]);
            continue;
        }

        if (!strncmp(line, "test", 4))
            test();
    }

    return 0;
}

void test(void) {

    PIECE b;

    //print_player(&my_player);

    init_piece(&b, 'S');
    print_piece(&b);
    rotate_right(&b);
    print_piece(&b);
    rotate_right(&b);
    print_piece(&b);
    rotate_right(&b);
    print_piece(&b);
    rotate_right(&b);
    print_piece(&b);

    rotate_left(&b);
    print_piece(&b);
    rotate_left(&b);
    print_piece(&b);
    rotate_left(&b);
    print_piece(&b);
    rotate_left(&b);
    print_piece(&b);
    rotate_left(&b);
    print_piece(&b);
}

void action(char *type, char *time) {
    assert(type != NULL);
    assert(time != NULL);
    
    if (!strcmp(type, "moves"))
        do_moves(atoi(time));
    else
        fprintf(stderr, "action: unknown type: [%s]\n", type);
}

void do_moves(int time) {
    PIECE   this_piece;
    PIECE   next_piece;
    int     lowest_row;
    int     lowest_col;
    int     i;
    
	//fprintf(stderr, "do_moves.1\n");

    init_piece(&this_piece, game_state.this_piece_type);
    init_piece(&next_piece, game_state.next_piece_type);

	//fprintf(stderr, "do_moves.2\n");

    find_lowest_row(my_player.field, &this_piece, &lowest_row, &lowest_col);
	
	fprintf(stderr, "do_moves.3 %d %d\n", lowest_row, lowest_col);
	fprintf(stderr, "do_moves.4 %d %d\n", game_state.this_piece_position_row, game_state.this_piece_position_col);
	    
    //printf("do_moves: lrow=%d lcol=%d\n", lowest_row, lowest_col);
    
    if (lowest_col < game_state.this_piece_position_col) {
		for (i = lowest_col; i < game_state.this_piece_position_col; i++) {
            fprintf(stdout, "LEFT,");
            //fprintf(stderr, "LEFT,");
		}
    }
    else {
		for (i = game_state.this_piece_position_col; i < lowest_col; i++) {
            fprintf(stdout, "RIGHT,");
            //fprintf(stderr, "RIGHT,");
		}
    }
    
    fprintf(stdout, "DROP\n");
	fflush(stdout);
    //fprintf(stderr, "DROP\n");

	//set_piece(my_player.field, &this_piece, lowest_row, lowest_col);
	//print_player(&my_player);
}

void set_piece(char *field, PIECE *piece, int row, int col) {
    int     prow;
    int     pcol;
    
    for (prow = 0; prow < piece->size; prow++) {
        for (pcol = 0; pcol < piece->size; pcol++) {
            if (piece->shapes[piece->current_shape][prow * piece->size + pcol] == '0')
                continue;
            field[(row + prow) * game_settings.field_width + (col + pcol)] = '1';
        }
    }
}

int piece_fits_at(char *field, int row, int col, PIECE *piece) {
    int     prow;
    int     pcol;
    
    for (prow = 0; prow < piece->size; prow++) {
        for (pcol = 0; pcol < piece->size; pcol++) {
            if (piece->shapes[piece->current_shape][prow * piece->size + pcol] == '0')
                continue;
            if (row + prow >= game_settings.field_height)
                return 0;
            if (col + pcol >= game_settings.field_width)
                return 0;
            if (field[(row + prow) * game_settings.field_width + (col + pcol)] != '0')
                return 0;
        }
    }
	for (prow = row - 1; prow >= 0; prow--) {
		for (pcol = col; pcol < piece->size; pcol++) {
            if (field[prow * game_settings.field_width + (col + pcol)] != '0')
               return 0;
		}
	}
    return 1;
}

void find_lowest_row(char *field, PIECE *piece, int *lowest_row, int *lowest_col) {
    int     row;
    int     col;
	int		best_row = -1;
    
    assert(lowest_row != NULL);
    assert(lowest_col != NULL);
    
    *lowest_row = *lowest_col = 0;
    
    for (row = 0; row < game_settings.field_height; row++) {
        for (col = 0; col < game_settings.field_width; col++) {
            if (piece_fits_at(field, row, col, piece) && row > best_row) {
                *lowest_row = row;
                *lowest_col = col;
				best_row = row;
            }
        }
    }
}
/*
settings timebank 10000
settings time_per_move 500
settings player_names player1,player2
settings your_bot player1
settings field_height 20
settings field_width 10
*/
void settings(char *type, char *value) {

    assert(type != NULL);
    assert(value != NULL);
    
	//fprintf(stderr, "settings [%s]=[%s]\n", type, value);

    if (!strcmp(type, "timebank"))
        game_settings.timebank = atoi(value);
    else
    if (!strcmp(type, "time_per_move"))
        game_settings.time_per_move = atoi(value);
    else
    if (!strcmp(type, "player_names"))
        strcpy(game_settings.player_names, value);
    else
    if (!strcmp(type, "your_bot"))
        strcpy(game_settings.my_bot_name, value);
    else
    if (!strcmp(type, "field_height"))
        game_settings.field_height = atoi(value);
    else
    if (!strcmp(type, "field_width"))
        game_settings.field_width = atoi(value);
    else
        fprintf(stderr, "settings: unknown type: [%s]\n", type);
}

/*
update game round 1
update game this_piece_type O
update game next_piece_type I
update game this_piece_position 4,-1
update player1 row_points 0
update player1 combo 0
update player1 skips 0
update player1 field 0,0,0,0,1,1,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0
update player2 row_points 0
update player2 combo 0
update player2 field 0,0,0,0,1,1,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0
*/
void update(char *player, char *type, char *value) {

    assert(player != NULL);
    assert(type != NULL);
    assert(value != NULL);

	//fprintf(stderr, "update player=[%s] [%s]=[%s]\n", player, type, value);
    
    if (!strcmp(player, "game")) {
        if (!strcmp(type, "round"))
            game_state.round = atoi(value);
        else
        if (!strcmp(type, "this_piece_type"))
            game_state.this_piece_type = value[0];
        else
        if (!strcmp(type, "next_piece_type"))
            game_state.next_piece_type = value[0];
        else
        if (!strcmp(type, "this_piece_position"))
            sscanf(value, "%d,%d", &game_state.this_piece_position_col, &game_state.this_piece_position_row);
        else
            fprintf(stderr, "update: unknown game type: [%s]\n", type);
        return;
    }

    if (!strcmp(player, game_settings.my_bot_name))
        update_player(&my_player, type, value);
    else
        update_player(&opp_player, type, value);
}

void update_player(PLAYER *player, char *type, char *value) {
    int     row;
    int     col;
    int     i;

    assert(player != NULL);
    assert(type != NULL);
    assert(value != NULL);
    
    if (!strcmp(type, "row_points"))
        player->row_points = atoi(value);
    else
    if (!strcmp(type, "combo"))
        player->combo = atoi(value);
    else
    if (!strcmp(type, "skips"))
        player->skips = atoi(value);
    else
    if (!strcmp(type, "field")) {
        if (player->field == NULL) {
            player->field = (char *)malloc(game_settings.field_height * game_settings.field_width);
            if (player->field == NULL) {
                fprintf(stderr, "update_player: malloc failed for player->field.\n");
                return;
            }
        }
        for (row = col = i = 0; value[i]; i++) {
            switch(value[i]) {
            case ',': col++; break;
            case ';': row++; col = 0; break;
            default: player->field[row * game_settings.field_width + col] = value[i]; break;
            }
       }
    }
    else
        fprintf(stderr, "update_player: unknown type: [%s]\n", type);
}

char field_cell_string(char cell) {
    switch(cell) {
    case '0': return CELL_EMPTY;
    case '1': return CELL_SHAPE;
    case '2': return CELL_BLOCK;
    case '3': return CELL_SOLID;
    default: return CELL_UNKNOWN;
    }
}

void print_player(PLAYER *player) {
    int     row;
    int     col;

    assert(player != NULL);

    fprintf(stderr, "row_points: %d combo: %d skips: %d\n", player->row_points, player->combo, player->skips);

    for (row = 0; row < game_settings.field_height; row++) {
        fprintf(stderr, "   ");
        for (col = 0; col < game_settings.field_width; col++)
            fprintf(stderr, "+---");
        fprintf(stderr, "+\n");

        for (col = 0; col < game_settings.field_width; col++) {
            if (col == 0)
                fprintf(stderr, "%2d |", row);
            fprintf(stderr, " %c |", field_cell_string(player->field[row * game_settings.field_width + col]));
        }

        fprintf(stderr, " %2d\n", row);
    }

    fprintf(stderr, "   ");
    for (col = 0; col < game_settings.field_width; col++)
        fprintf(stderr, "+---");
    fprintf(stderr, "+\n");
}

void init_piece(PIECE *piece, char type)
{
    assert(piece != NULL);

    memset(piece, 0, sizeof(PIECE));

    switch(type) {
    case 'I':
        piece->type = 'I';
        piece->size = 4;
        piece->current_shape = 0;
        piece->shapes = I_SHAPE;
        piece->max_shapes = 4;
        break;
    case 'Z':
        piece->type = 'Z';
        piece->size = 3;
        piece->current_shape = 0;
        piece->shapes = Z_SHAPE;
        piece->max_shapes = 4;
        break;
    case 'L':
        piece->type = 'L';
        piece->size = 3;
        piece->current_shape = 0;
        piece->shapes = L_SHAPE;
        piece->max_shapes = 4;
        break;
    case 'J':
        piece->type = 'J';
        piece->size = 3;
        piece->current_shape = 0;
        piece->shapes = J_SHAPE;
        piece->max_shapes = 4;
        break;
    case 'O':
        piece->type = 'O';
        piece->size = 2;
        piece->current_shape = 0;
        piece->shapes = O_SHAPE;
        piece->max_shapes = 1;
        break;
    case 'T':
        piece->type = 'T';
        piece->size = 3;
        piece->current_shape = 0;
        piece->shapes = T_SHAPE;
        piece->max_shapes = 4;
        break;        
    case 'S':
        piece->type = 'S';
        piece->size = 3;
        piece->current_shape = 0;
        piece->shapes = S_SHAPE;
        piece->max_shapes = 4;
        break; 
    default:
        fprintf(stderr, "init_piece: unknown type: [%c]\n", type);
    }
}

void rotate_right(PIECE *piece) {
    assert(piece != NULL);
    piece->current_shape = (piece->current_shape == piece->max_shapes - 1 ? 0 : piece->current_shape + 1);
}

void rotate_left(PIECE *piece) {
    assert(piece != NULL);
    piece->current_shape = (piece->current_shape == 0 ? piece->max_shapes - 1 : piece->current_shape - 1);
}

void print_piece(PIECE *piece) {
    int     row;
    int     col;

    assert(piece != NULL);

    for (row = 0; row < piece->size; row++) {
        for (col = 0; col < piece->size; col++)
            fprintf(stderr, "+-");
        fprintf(stderr, "+\n");
        fprintf(stderr, "|");

        for (col = 0; col < piece->size; col++)
            fprintf(stderr, "%c|", (piece->shapes[piece->current_shape][row * piece->size + col] == '1' ? CELL_BLOCK : CELL_EMPTY));
        fprintf(stderr, "\n");
    }

    for (col = 0; col < piece->size; col++)
        fprintf(stderr, "+-");
    fprintf(stderr, "+\n\n");
}

 

/*

Communicating with the game engine

 

The communication between your bot and the engine goes via the standard input and output channels. Every single line the engine gives is a specific piece of information or a request. The response from your bot should also be just one line. Starting with this competition we have standardized the API, so all new competitions will also work with this API. There are three types of lines, in the following format:

�settings [type] [value] given only at the start of the game. General settings of the game are given here.

�action [type] [time] indicates a request for an action.

�update [player] [type] [value] this is an update of the game state. [player] indicates what bot the update is about, but could also be 'game' to indicate a general update.

 

In the table below you can find all specific commands your bot can expect for this competition. The format for an action response is also given.

Output from engineDescription`

settings timebank t  Maximum time in milliseconds that your bot can have in its time bank

settings time_per_move t  Time in milliseconds that is added to your bot's time bank each move

settings player_names [b,...]  A list of all player names in this match, including your bot's name

settings your_bot b  The name of your bot for this match

settings field_width i  The width of the field, i.e. number of row-cells

settings field_height i  The height of the field, i.e. number of column-cells

update game round i  The number of the current round

update game this_piece_type s  The type of the piece that has just spawned on the field

update game next_piece_type s  The type of the piece that will spawn the next round

update game this_piece_position i,i The starting position in the field for the current piece (top left corner of the piece bounding box)

update b row_points i The amount of row points the given player has scored so far

update b combo i The height of the current combo for the given player

update b skips i The amount of skips the given player has available

update b field [[c,...];...] The complete playing field of the given player

action moves t Request for the whole set of moves for this round

Output from botDescription

[m,...] A list of moves separated by comma's

 

Each "i" can be any integer. Each "b" is represents the name of a bot (as far as the engine is concerned) and can be either player1 or player2 for this competition.

"t" represents a time in milliseconds.

A "c" is a cell type of the playing field. This can be a 0, 1, 2 or 3, for empty, shape, block or solid respectively. Shape means that the cell is part of the current moving piece (shape) in the field, a block is one of the cells that can be set to empty again by clearing a row, and a solid cell is at the bottom of the field, sent to you by your opponent. Solid cells cannot change again. The "c" can only be found in the field updates; cells in a row are separated by comma's and the rows are separated by semicolons (see the section below for an example). "s" is one of the 7 piece types and can be either I, J, L, O, S, T or Z. Finally, the "m" in the bot's response can be one of the following moves: down, left, right, turnleft, turnright, drop or skip. Output "no_moves" if you want your bot to do nothing, rather than letting it time out, so the bot is not shut down by the engine for being defect. For this competition the default action is drop.

 

The engine will always try to perform the action given by the output of your bot. In case the action is not valid in the current game situation, the engine will output a warning and either skip the action (turnleft/turnright), change it to 'down' (left/right) or freeze the piece in place (down).

 

Input and output between the bot and the engine go via the standard input and output channels, but you can use the error output channel to print stuff in the error dump of your game. This will not be read by the engine and can be used for debugging.

 

By example

 

The game itself is not very difficult to understand, but to make it a bit more clear what the inputs and outputs look like we're providing an example. You can find this in the dump of any of your own games as well.

settings timebank 10000
settings time_per_move 500
settings player_names player1,player2
settings your_bot player1
settings field_height 20
settings field_width 10
update game round 1
update game this_piece_type O
update game next_piece_type I
update game this_piece_position 4,-1
update player1 row_points 0
update player1 combo 0
update player1 skips 0
update player1 field 0,0,0,0,1,1,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0
update player2 row_points 0
update player2 combo 0
update player2 field 0,0,0,0,1,1,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0
action moves 10000
 

These are the settings of the game. This information is sent at the start of a match only. Your bot now knows the timebank settings, the player names and the field dimensions. Continuing with the rest of the input/output:

update game round 1

update game this_piece_type O

update game next_piece_type I

update game this_piece_position 4,-1

 

 

Your bot gets updates about the game in general. More specific, it gets the round number and information about the current and next piece. Continuing.

update player1 row_points 0

update player1 combo 0

update player1 skips 0

update player1 field 0,0,0,0,1,1,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0

 

 

These are the updates about your bot (player1). The current points, skips and combo are 0, because this is just the start of the game. The field is empty, except for the O piece that has spawned at the top.

update player2 row_points 0

update player2 combo 0

update player2 field 0,0,0,0,1,1,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0;0,0,0,0,0,0,0,0,0,0

 

Next your bot gets the updates about your opponent. Again the points, combo and field, but at the start of the game they are the same as your own bot's updates.

action moves 10000

left,left,left,left,drop //output from your bot

*/